########### Python 3.2 #############
import http.client, urllib.request, urllib.parse, urllib.error, base64
import json
def luisQuestion(question):
	data="";
	headers = {
		# Request headers
		'Ocp-Apim-Subscription-Key': 'df96af6e378e400eb00b0986d737139f',
	}

	params = urllib.parse.urlencode({
		# Request parameters
		'q':question,
		'timezoneOffset': '480',
		'verbose': 'true',
		'spellCheck': 'false',
		'staging': 'false',
	})
	#https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/?subscription-key=&timezoneOffset=&verbose=&q=

	try:
		conn = http.client.HTTPSConnection('westus.api.cognitive.microsoft.com')
		conn.request("GET", "/luis/v2.0/apps/1851f758-c654-40f2-b55c-f89fdaad9ccf?%s" % params, "{body}", headers)
		response = conn.getresponse()
		data = json.loads(response.read().decode('utf-8'))
		data = data['topScoringIntent']['intent']
		conn.close()
	except Exception as e:
		 print("[Errno {0}] {1}".format(e.errno, e.strerror))

	return data
####################################

