
def find_all_index(arr,item):
    return [i for i,a in enumerate(arr) if a==item]